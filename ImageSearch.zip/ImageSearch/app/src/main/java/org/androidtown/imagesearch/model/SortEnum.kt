package org.androidtown.imagesearch.model

enum class SortEnum (val sort:String){
        Accuracy("accuracy"),
        Recency("recency")
    }
